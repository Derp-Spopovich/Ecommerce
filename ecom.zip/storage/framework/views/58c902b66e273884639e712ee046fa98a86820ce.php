<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
    <p class="m-0 text-center text-white">&copy; Made by Hanphil</p>
    </div>
    <!-- /.container -->
</footer><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/includes/footer.blade.php ENDPATH**/ ?>