
<?php $__env->startSection('content'); ?>
  <div class="container">
    <p class="display-4">Search Result</p>
    <p><?php echo e($products->count()); ?> result(s) for <?php echo e(request()->input('query')); ?></p>
    <table class="table">
      <thead class="thead-dark">
        <tr>
            <th scope="col">Product</th>
            <th scope="col">Product Name</th>
            <th scope="col">Details</th>
            <th scope="col">Category</th>
            <th scope="col">Price</th>
        </tr>
      </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                <td><a href="<?php echo e(route('products.show', $product)); ?>"><img src="<?php echo e(url('/products_photos/'.$product->photo)); ?>" alt="product photo" style="height: 80px;"></a></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->detail); ?></td>
                <td><a href="<?php echo e(route('products.index', ['category' => $product->category->name])); ?>"><?php echo e($product->category->name); ?></td>
                <td><?php echo e($product->price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No Products in search result
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($products->links()); ?>

   
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/products/search.blade.php ENDPATH**/ ?>