<div>
    <button type="button" class="btn btn-primary">
        Rating: <span class="badge badge-light"><?php echo e(round($ratings->avg('rating'), 2)); ?></span> <small>/5</small> <!--get the average rating of the product -->
    </button>
    <div class="accordion" id="accordionExample"  style="width: 30rem;">
        <div class="card">
          <div class="card-header" id="headingOne">
            <h2 class="mb-0">
              <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                Give Comment and rating
              </button>
            </h2>
          </div>
      
          <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
            <div class="card-body">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="/login">Login</a> to give rating
                <?php else: ?>
                <form method="POST" action="<?php echo e(route('ratings.store', $product->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <small class="form-text text-muted">Please dont be rude to the owner or other users</small>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                          <label>Comment</label>
                          <input type="text" name="comment" value="<?php echo e(old('comment')); ?>" class="form-control">
                            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('update', $product)): ?>
                            <div class="col-2">
                                <label for="exampleFormControlSelect1">Rating</label>
                                <select class="form-control" name="rating">
                                    <option>0</option>
                                    <option>1</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
                                </select>
                            </div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="card">
            <div class="card-header">
              Comments and ratings
            </div>
            <ul class="list-group list-group-flush">
                <?php $__empty_1 = true; $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <small><?php echo e($rating->created_at->diffForHumans()); ?></small>
                    <li class="list-group-item"><?php echo e($rating->user->name); ?> <small>said</small>:  <?php echo e($rating->comment); ?>

                         <?php if(!empty($rating->rating)): ?>
                        <code><?php echo e($rating->rating); ?>star</code>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $product)): ?>
                            <form action="<?php echo e(route('ratings.destroy',$rating->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="badge badge-danger">delete</button>
                            </form>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    No rating yet
                <?php endif; ?>
            </ul>
        </div>
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/livewire/comments.blade.php ENDPATH**/ ?>