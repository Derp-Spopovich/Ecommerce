
<?php $__env->startSection('content'); ?>
<div class="container px-lg-5">
    <div class="row mx-lg-n5">
        <div class="col py-3 px-lg-5 border bg-light"> <!-- start of first row -->
            <div class="col-mb-4">
                <div class="card">
                  <img src="<?php echo e(url('products_photos/'.$product->photo)); ?>" class="product-show">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                        <p class="card-text">
                            Price: <?php echo e($product->price); ?> php
                        </p>
                        <p class="card-text">
                            Details: <?php echo e($product->detail); ?>

                        </p>
                        <p class="card-text">
                            Category: <a href="<?php echo e(route('products.index', ['category' => $product->category->name])); ?>"><?php echo e($product->category->name); ?></a>
                        </p>
                        <p class="card-text">
                            Seller: <a href="<?php echo e(route('users.show', $product->user)); ?>"><?php echo e($product->user->name); ?></a>
                        </p>
                    </div>
                    <div class="container">
                        <div class="row row-cols-2">
                            <?php if(auth()->guard()->guest()): ?>
                                <p>Login to buy/cart products</p>
                            <?php else: ?>
                                <div class="col">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('update', $product)): ?>
                                        <form action="<?php echo e(route('carts.store', $product->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php if(auth()->user()->addedToCart($product)): ?> 
                                                <button class="btn btn-outline-danger">Remove to cart</button>
                                        <?php else: ?>
                                            <button class="btn btn-outline-success">Add to cart</button>
                                        <?php endif; ?>
                                            
                                        </form>
                                </div>
                                <div class="col">
                                    <a href="<?php echo e(route('payments.create',$product)); ?>"><button class="btn btn-outline-primary">Buy now</button></a>
                                </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!--end of first row -->
        <div class="col py-3 px-lg-5 border bg-light">
            <button type="button" class="btn btn-primary">
                Rating: <span class="badge badge-light"><?php echo e(round($ratings->avg('rating'), 2)); ?></span> <small>/5</small> <!--get the average rating of the product -->
            </button>
            <div class="accordion" id="accordionExample">
                <div class="card">
                    <div class="card-header" id="headingOne">
                        <h2 class="mb-0">
                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Give Comment and rating
                            </button>
                        </h2>
                    </div>
                </div>
            
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                    <div class="card-body">
                        <?php if(auth()->guard()->guest()): ?>
                            <a href="/login">Login</a> to give rating
                        <?php else: ?>
                        <form method="POST" action="<?php echo e(route('ratings.store', $product->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <small class="form-text text-muted">Please dont be rude to the owner or other users</small>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label>Comment</label>
                                    <input type="text" name="comment" value="<?php echo e(old('comment')); ?>" class="form-control">
                                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('update', $product)): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('seller-users')): ?>
                                        <div class="col-md-2">
                                            <label for="exampleFormControlSelect1">Rating</label>
                                            <select class="form-control" name="rating">
                                                <option></option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        Comments and ratings
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php $__empty_1 = true; $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <small><?php echo e($rating->created_at->diffForHumans()); ?></small>
                            <li class="list-group-item"><?php echo e($rating->user->name); ?> <small>said</small>:  <?php echo e($rating->comment); ?>

                                <?php if(!empty($rating->rating)): ?>
                                <code><?php echo e($rating->rating); ?>star</code>
                                <?php endif; ?>
                                <?php if(auth()->user()->id === $rating->user->id): ?>
                                    <form action="<?php echo e(route('ratings.destroy',$rating->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="badge badge-danger">delete</button>
                                    </form>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            No rating yet
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div> <!-- end of 2nd row -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/products/show.blade.php ENDPATH**/ ?>