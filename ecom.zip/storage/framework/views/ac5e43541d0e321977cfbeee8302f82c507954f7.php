
<?php $__env->startSection('content'); ?>

<div class="container">
    <p class="display-4">Product Detail</p>
    <hr>
    <div class="row">
        <div class="col-sm">
            <a href="<?php echo e(route('products.show',$product)); ?>">
                <img src="<?php echo e(url('products_photos/'.$product->photo)); ?>" style="height: 100px" alt="">
            </a>
        </div>
        <div class="col-sm">
            <a href="">
                <?php echo e($product->name); ?>

            </a>
            <div class="row">
                <div class="col-sm">
                    <small class="form-text text-muted"><?php echo e($product->detail); ?></small>
                </div>
            </div>
        </div>
        <div class="col-sm">
            <?php echo e($product->price); ?> php
        </div>
    </div>

    <hr>

    <br>

    <div class="card">
        <div class="card-header">
          Delivery Information
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('payments.store', $product)); ?>">
                <?php echo csrf_field(); ?>
                <small class="form-text text-muted">Please provide the complete detail</small>
                <div class="form-row">
                    <div class="form-group col-md-6">
                      <label>Full Name</label>
                      <input type="text" name="fullName" value="<?php echo e(old('fullName')); ?>" class="form-control">
                        <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-6">
                      <label>Contact Number</label>
                      <input type="number" name="contact" value="<?php echo e(old('contact')); ?>" class="form-control" placeholder="09xx" min="1">
                    <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputAddress">Complete Address</label>
                    <input type="text" name="address" value="<?php echo e(old('address')); ?>" class="form-control" placeholder="1234 Main St">
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <div class="col-7">
                        <label for="exampleFormControlSelect1">Payment Method</label>
                        <select class="form-control" name="mop">
                            <option>Cash On Delivery</option>
                            <option disabled>Credit/Debit Card</option>
                            <option disabled>Payment Center/E-wallet</option>
                            <option disabled>Over the counter</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-2">
                        <label for="exampleFormControlSelect1">Quantity</label>
                        <select class="form-control" name="quantity">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Place Order</button>
            </form>
        </div>
    </div>
       
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/payments/create.blade.php ENDPATH**/ ?>