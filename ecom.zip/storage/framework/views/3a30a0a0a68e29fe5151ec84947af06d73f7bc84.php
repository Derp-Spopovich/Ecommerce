<div>
    <form wire:submit.prevent="store">
        <?php echo csrf_field(); ?>
        <small class="form-text text-muted">Please dont be rude to the owner or other users</small>
        <div class="form-row">
            <div class="form-group col-md-6">
              <label>Comment</label>
              <input type="hidden" wire:model="product_id">
              <input type="text" wire:model="comment" class="form-control">
                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            
                <div class="col-2">
                    <label for="exampleFormControlSelect1">Rating</label>
                    <select class="form-control" wire:model="rating">
                        <option></option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </select>
                </div>
                
            
            
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/livewire/create-rating.blade.php ENDPATH**/ ?>