<?php $__env->startSection('content'); ?>
<div>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <img src="<?php echo e(url('products_photos/'.$product->photo)); ?>" class="show-img" alt="Product image">
            </div>
            <div class="col-sm-6">
                <a href="<?php echo e(route('products.index')); ?>">Go back</a>
                <h2 class="mt-3"><?php echo e($product->name); ?></h2>
                <h3>Price: <?php echo e($product->price); ?> php</h3>
                <h3>Details: <?php echo e($product->detail); ?></h3>
                <h3>Category: <a href="<?php echo e(route('products.index', ['category' => $product->category->name])); ?>"><?php echo e($product->category->name); ?></a></h3>
                <h3>Seller: <a href="<?php echo e(route('users.show', $product->user)); ?>"><?php echo e($product->user->name); ?></a></h3>
                <br><br>
                <?php if(auth()->guard()->guest()): ?>
                    <p>Login to buy/cart products</p>
                <?php else: ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('update', $product)): ?>
                        <form action="<?php echo e(route('carts.store', $product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(auth()->user()->addedToCart($product)): ?> 
                                <button class="btn btn-outline-danger">Remove to cart</button>
                            <?php else: ?>
                                <button class="btn btn-outline-success">Add to cart</button>
                            <?php endif; ?>
                            
                        </form>
                        <br><br>
                        <a href="<?php echo e(route('payments.create',$product)); ?>"><button class="btn btn-outline-primary">Buy now</button></a>
                    <?php endif; ?>
                <?php endif; ?>
                
            </div>
        </div> <!--end-->

        <br>
        
     
        <button type="button" class="btn btn-primary">
            Rating: <span class="badge badge-light"><?php echo e(round($ratings->avg('rating'), 2)); ?></span> <small>/5</small> <!--get the average rating of the product -->
        </button>
        <div class="accordion" id="accordionExample"  style="width: 30rem;">
            <div class="card">
              <div class="card-header" id="headingOne">
                <h2 class="mb-0">
                  <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Give Comment and rating
                  </button>
                </h2>
              </div>
          
              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                <div class="card-body">
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="/login">Login</a> to give rating
                    <?php else: ?>
                        <?php echo $__env->make('livewire.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
              </div>
            </div>
    
            <div class="card">
                <div class="card-header">
                  Comments and ratings
                </div>
                <ul class="list-group list-group-flush">
                    <?php $__empty_1 = true; $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <small><?php echo e($rating->created_at->diffForHumans()); ?></small>
                        <li class="list-group-item"><?php echo e($rating->user->name); ?> <small>said</small>:  <?php echo e($rating->comment); ?>

                             <?php if(!empty($rating->rating)): ?>
                            <code><?php echo e($rating->rating); ?>star</code>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $product)): ?>
                                <form action="<?php echo e(route('ratings.destroy',$rating->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="badge badge-danger">delete</button>
                                </form>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No rating yet
                    <?php endif; ?>
                </ul>
            </div>
            
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/livewire/show-product.blade.php ENDPATH**/ ?>