
<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Options</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('users.show', $user)); ?>"><?php echo e($user->name); ?></a></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e(implode(',',$user->roles()->pluck('name')->toArray())); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.edit', $user->id)); ?>"><button class="btn btn-outline-primary">Edit</button></a>
                            <form action="<?php echo e(route('users.delete', $user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/users/index.blade.php ENDPATH**/ ?>