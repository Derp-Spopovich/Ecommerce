
<?php $__env->startSection('content'); ?>
<main role="main">

    <section class="jumbotron text-center">
      <div class="container">
        <h1><?php echo e(ucwords($user->name)); ?></h1>
        <?php if(empty($user->bio)): ?>
            <p class="lead text-muted">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
        <?php else: ?>
            <p class="lead text-muted"><?php echo e($user->bio); ?> </p>
        <?php endif; ?>
        
        <small>Joined <?php echo e($user->created_at->diffForHumans()); ?></small>
        <br>
        <small><?php echo e(implode(',',$user->roles()->pluck('name')->toArray())); ?></small>
        <p>
            <?php if(auth()->user()->is($user)): ?>
                <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-secondary my-2">Edit Profile</a>
            <?php endif; ?>
        </p>
      </div>
    </section>
  
    <div class="album py-5 bg-light">
        <div class="container">
            <div class="row">

                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <div class="card mb-4 shadow-sm">
                        <img src="<?php echo e(url('products_photos', $product->photo)); ?>" class="card-img-top" style="height: 200px" alt="">
            
                        <div class="card-body">
                        <p class="card-text"><?php echo e($product->name); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <a href="<?php echo e(route('products.show', $product->id)); ?>"><button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $product)): ?>
                                        <a href="<?php echo e(route('products.edit', $product->id)); ?>"><button type="button" class="btn btn-sm btn-outline-secondary">Edit</button></a>
                                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <small class="text-muted"><?php echo e($product->price); ?> php</small>
                        </div>
                        </div>
                    </div>
                </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <small> No products posted yet</small> 
                <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/users/show.blade.php ENDPATH**/ ?>