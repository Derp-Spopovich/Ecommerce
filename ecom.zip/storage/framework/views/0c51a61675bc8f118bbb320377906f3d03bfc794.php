
<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row">

        <div class="col-lg-3">

            <h1 class="my-4">Ecommerce</h1>
            <div class="list-group">
                <a href="<?php echo e(route('products.index')); ?>" class="list-group-item">All</a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('products.index', ['category' => $category->name])); ?>" class="list-group-item"><?php echo e($category->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            <div class="list-group mt-2">
                <p>Sort by price</p>
                <a href="<?php echo e(route('products.index', ['category' => request()->category, 'sort' => 'low_high'])); ?>" class="list-group-item">low to high</a>
                <a href="<?php echo e(route('products.index', ['category' => request()->category, 'sort' => 'high_low'])); ?>" class="list-group-item">high to low</a>
            </div>
           

        </div>
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

            <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                <img class="d-block img-fluid banner-img" src="<?php echo e(url('/banner/banner3.jpg')); ?>" alt="First slide">
                </div>
                <div class="carousel-item">
                <img class="d-block img-fluid banner-img" src="<?php echo e(url('/banner/banner4.jpg')); ?>" alt="Second slide">
                </div>
                <div class="carousel-item">
                <img class="d-block img-fluid banner-img" src="<?php echo e(url('/banner/banner5.png')); ?>" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
            </div>

            <div class="row">

            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100">
                    <a href="<?php echo e(route('products.show', $product->id)); ?>"><img class="card-img-top" src="<?php echo e(url('/products_photos/' .$product->photo)); ?>" style="height: 200px" alt=""></a>
                    <div class="card-body">
                        <h4 class="card-title">
                        <a href="<?php echo e(route('products.show', $product->id)); ?>"><?php echo e($product->name); ?></a>
                        </h4>
                        <h5><?php echo e($product->price); ?> php</h5>
                        <p class="card-text"><?php echo e($product->detail); ?></p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                    </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-lg-4">
                    <p>No relevant products posted yet</p>
                </div>
            <?php endif; ?>

            <?php echo e($products->appends(request()->input())->links()); ?> <!-- if theres already existing query string, it will not refresh. -->

            </div>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/products/index.blade.php ENDPATH**/ ?>