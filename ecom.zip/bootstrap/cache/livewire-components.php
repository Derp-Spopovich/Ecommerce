<?php return array (
  'show-product' => 'App\\Http\\Livewire\\ShowProduct',
);