
<?php $__env->startSection('content'); ?>
  <div class="container">
    <p class="display-4">Ordered Details</p>
    <table class="table">
      <thead class="thead-dark">
        <tr>
          <th scope="col">Product</th>
          <th scope="col">Product Name</th>
          <th scope="col">Full Name</th>
          <th scope="col">Address</th>
          <th scope="col">ContactNumber</th>
          <th scope="col">Mode Of Payment</th>
          <th scope="col">Product Price</th>
          <th scope="col">Quantity</th>
          <th scope="col">Total Price</th>
          <th scope="col">Ordered Date</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><a href="<?php echo e(route('products.show', $payment->product)); ?>"><img src="<?php echo e(url('/products_photos/'.$payment->product->photo)); ?>" alt="product photo" style="height: 80px;"></a></td>
          <td><?php echo e($payment->product->name); ?></td>
          <td><?php echo e($payment->fullname); ?></td>
          <td><?php echo e($payment->complete_address); ?></td>
          <td><?php echo e($payment->contact_number); ?></td>
          <td><?php echo e($payment->mode_of_payment); ?></td>
          <td><?php echo e($payment->product->price); ?></td>
          <td><?php echo e($payment->quantity); ?></td>
          <td><?php echo e($payment->total_price); ?></td>
          <td><?php echo e($payment->created_at->format('M/d/y')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No orders yet. <a href="/">View Products</a></p>
      <?php endif; ?>
      </tbody>
    </table>
   
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/payments/index.blade.php ENDPATH**/ ?>