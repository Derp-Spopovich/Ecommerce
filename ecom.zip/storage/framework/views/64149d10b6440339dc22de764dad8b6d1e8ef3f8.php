
<?php $__env->startSection('content'); ?>
    <div class="container">
        <strong><?php echo e($carts->count()); ?> Item(s) in shopping cart</strong>
        <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <hr>
            <div class="row">
                <div class="col-sm-2">
                    <a href="<?php echo e(route('products.show',$cart)); ?>">
                        <img src="<?php echo e(url('products_photos/'.$cart->photo)); ?>" style="height: 100px" alt="">
                    </a>
                </div>
                <div class="col-sm">
                    <a href="<?php echo e(route('products.show',$cart)); ?>">
                        <?php echo e($cart->name); ?>

                    </a>
                    <div class="row">
                        <div class="col-sm">
                            <small class="form-text text-muted"><?php echo e($cart->detail); ?></small>
                        </div>
                    </div>
                </div>
                <div class="col-sm">
                    <?php echo e($cart->price); ?> php
                </div>
                <div class="col-sm">
                    <a href="<?php echo e(route('payments.create', $cart)); ?>" class="btn btn-outline-primary mb-2">Buy</a>
                    <form action="<?php echo e(route('carts.store', $cart)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline-danger"><?php echo e(auth()->user()->addedToCart($cart) ? 'Remove to cart' : 'Add to cart'); ?> </button>
                    </form>
                </div>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <br>
        No Products put in cart yet. <a href="/">View Products</a>
        <?php endif; ?>
        <?php echo e($carts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/carts/show.blade.php ENDPATH**/ ?>