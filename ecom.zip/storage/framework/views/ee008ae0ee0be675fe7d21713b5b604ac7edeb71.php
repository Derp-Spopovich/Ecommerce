
<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Product Name</th>
                <th scope="col">Posted By</th>
                <th scope="col">Product Price</th>
                <th scope="col">Date Created</th>
                <th scope="col">Options</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('products.show', $product)); ?>"><img src="<?php echo e(url('products_photos/'.$product->photo)); ?>" alt="" style="height: 100px"></a></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><a href="<?php echo e(route('users.show',$product->user)); ?>"><?php echo e($product->user->name); ?></a></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->created_at->format('M/d/y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.edit_product', $product)); ?>"><button class="btn btn-outline-primary">Edit</button></a>
                            <form action="<?php echo e(route('admin.delete_product', $product)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <?php echo e($products->links()); ?>

        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/admin/products.blade.php ENDPATH**/ ?>