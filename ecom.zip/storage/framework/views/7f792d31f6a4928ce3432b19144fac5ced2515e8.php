<?php if(session('success')): ?>
    <div class="alert alert-success  alert-dismissible fade show container" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(session('deleted')): ?>
    <div class="alert alert-danger  alert-dismissible fade show container" role="alert">
        <?php echo e(session('deleted')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\ecom\resources\views/includes/alert.blade.php ENDPATH**/ ?>